$(document).ready(function(){

    // get rotation
    function getRotationDegrees(obj) {
        var matrix = obj.css("-webkit-transform") ||
        obj.css("-moz-transform")    ||
        obj.css("-ms-transform")     ||
        obj.css("-o-transform")      ||
        obj.css("transform");
        if(matrix !== 'none') {
            var values = matrix.split('(')[1].split(')')[0].split(',');
            var a = values[0];
            var b = values[1];
            var angle = Math.round(Math.atan2(b, a) * (180/Math.PI));
        } else { var angle = 0; }
        return (angle < 0) ? angle + 360 : angle;
    }

    // rotate and vibrate type
    setInterval(rotateSegment,20);
    setInterval(rotateBG,1000);


    var i = 1;

    var click = 0;

    $('body').click(function(){
        click++; 
        if(click == 4) {
            click=0;
            $('.letterbox div').each(function(){
                $(this).css('height', '10px');
            });
        }
    });
    function rotateSegment(){

        $('.letterbox div').each(function(){
                var current = getRotationDegrees($(this));
                //console.log(current);

                // get a random number between 5 and -5
                var colors = ['magenta', 'yellow', 'cyan'];

                var randomColor = Math.floor(Math.random() * 3);
                var randomHeight = Math.floor(Math.random() * 10);
                var randomHeight2 = Math.floor(Math.random() * 100);
                var randomNumber = 7;

                if( i%2 == 1) {
                    var rotate = current + randomNumber;
                
                } else {
                    var rotate = current - randomNumber;    
                }
                i++;
                
                console.log(rotate);

                if(click > 0){
                    $(this).css('transform', 'rotate('+rotate+'deg)');
                }
                if(click > 1){
                    $(this).css('height', randomHeight+'px');
                }
                if(click > 2){
                    $(this).css({'background': colors[randomColor], 'height': randomHeight2+'px'});
                }
        });



    }





    function rotateBG(){
        // get a random number between 5 and -5
        var colors = ['#FFB6C1', '#7B68EE', '#F08080','#FF69B4','#00FF7F'];

        var randomColor = Math.floor(Math.random() * 5);

           


        $('body').css('background', colors[randomColor]);
    }










});